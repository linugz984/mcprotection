configdb = {

    "CLIENT_ID": "",
    "CLIENT_SECRET": "",
    "REDIRECT_URI": "",
    "BOT_TOKEN": ""

}
